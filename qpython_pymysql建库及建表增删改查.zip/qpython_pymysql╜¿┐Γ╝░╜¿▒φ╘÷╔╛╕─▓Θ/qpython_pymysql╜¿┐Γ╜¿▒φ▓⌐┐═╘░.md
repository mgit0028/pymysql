

pymysql操作mysql数据库 原文博主


https://www.cnblogs.com/reyinever/p/10869434.html


老齐教室


https://github.com/qiwsir/ITArticles/tree/master/Python

scraapy官方安装帮助


http://doc.scrapy.org/en/latest/intro/install.html


找到Linux安装说明

PyPy

We recommend using the latest PyPy version. 

The version tested is 5.9.0. For PyPy3, only Linux installation was tested.

